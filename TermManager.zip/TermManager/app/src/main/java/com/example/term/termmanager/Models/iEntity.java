package com.example.term.termmanager.Models;

/**
 * Created by Dad on 2/3/2018.
 */

public interface iEntity {
    long getId();

}
